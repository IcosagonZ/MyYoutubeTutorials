Compile using: gcc -o MyApp myapp.c -Wall `pkg-config --cflags --libs gtk+-3.0` -export-dynamic

Run using: ./MyApp

(The compiled app which I made, may or may not work on your distribution)
